effect give @a speed 1 1
