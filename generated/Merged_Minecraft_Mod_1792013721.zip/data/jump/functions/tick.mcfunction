effect give @a jump_boost 1 1
