@echo off
echo ========================================================
echo Launching <html><head><title>Snake</title></head><body><h1>Snake</h1><canvas id=c width=400 height=400></canvas><script>console.log(1);</script></body></html>...
echo Created with Kaleb AI
echo ========================================================
start "" "html__head__title_Snake__title___head__body__h1_Snake__h1__canvas_id_c_width_400_height_400___canvas__script_console_log_1____script___body___html_1792014101.html"
