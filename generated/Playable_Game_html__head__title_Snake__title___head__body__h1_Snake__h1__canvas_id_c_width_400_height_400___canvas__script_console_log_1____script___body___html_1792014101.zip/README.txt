<html><head><title>Snake</title></head><body><h1>Snake</h1><canvas id=c width=400 height=400></canvas><script>console.log(1);</script></body></html>
Created by Kaleb AI

HOW TO PLAY:
1. Double-click 'Play_html__head__title_Snake__title___head__body__h1_Snake__h1__canvas_id_c_width_400_height_400___canvas__script_console_log_1____script___body___html.bat' (or open 'html__head__title_Snake__title___head__body__h1_Snake__h1__canvas_id_c_width_400_height_400___canvas__script_console_log_1____script___body___html_1792014101.html' in any web browser like Chrome, Edge, or Firefox).
2. Enjoy playing your game offline anytime!
